//Jagmeet Singh Gurm
//Prof: Dr. Yeung
//Assignment1
#ifndef NODE_H
#define NODE_H

class node
{public:
	char value;
	node *left;
	node *right;
	node *parent;


};
#endif