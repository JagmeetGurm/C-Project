#ifndef NODE_H
#define NODE_H

class node
{public:
	float data; //to store the data values
	
	node *next; //pointer of node type pointing to next node.
	node *prev; //pointer pointing to previous node.

};
#endif
